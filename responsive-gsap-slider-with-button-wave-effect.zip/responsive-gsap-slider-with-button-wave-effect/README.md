# Responsive GSAP Slider with Button Wave Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/icomgroup/pen/yLWLgwR](https://codepen.io/icomgroup/pen/yLWLgwR).

